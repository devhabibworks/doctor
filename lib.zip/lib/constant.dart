import 'package:flutter/material.dart';

Color pinkColor = const Color(0xffffe0f4);
Color purpleColor = const Color(0xff8a86e2);
Color blackColor = const Color(0xff32313a);
Color whiteColor = const Color(0xfffcfeff);
